<?php ob_start();?>
<?php session_start();?>
<!DOCTYPE html>
    <head>
        <title>QCM</title>
        <meta charset="utf-8">
        <link rel="stylesheet" media="screen and (min-width: 1000px) and (max-width: 1600px)"
        href="asset/CSS/designA70.css" type="text/css" />
        <link rel="stylesheet" media="screen and (min-width: 630px) and (max-width: 1000px)"
        href="asset/CSS/designB11.css" type="text/css" />
        <link rel="stylesheet" media="screen and (min-width: 320px) and (max-width: 630px)"
        href="asset/CSS/designC7.css" type="text/css" />
    </head>
    <body>
        <div class="conteneur">
            <div class="main">
                <h1 class="entete"><img class="logo" src="asset/IMG/logo-QuizzSA.png">Le plaisir de jouer</h1>
                <div id="ereur"></div>
                <?php
                    require "src/fonction.php";
                    if(isset($_GET["page"])){
                        if($_GET["page"]==2){
                            require "src/interfaceJoueur.php";
                        }
                        else if($_GET["page"]==0){
                            require "src/creationUser.php";
                        }
                        else{
                            require "src/interfaceAdmin.php";
                        }
                    }
                    else{
                        require "src/connexion.php";
                    }
                    $content=ob_get_clean();
                    echo $content;
                ?>
            </div>
        </div>
    </body>
</html>
<?php
?>