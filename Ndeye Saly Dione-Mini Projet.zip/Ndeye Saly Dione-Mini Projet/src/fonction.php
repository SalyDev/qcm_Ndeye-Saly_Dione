<?php
//fonction qui permet de se deconnecter
   function deconnexion($loginUser){
        if(isset($_POST["deconnexion"]) || !isset($loginUser)){
            header("Location:index.php");
            session_destroy();
        }
    }
 // fonction qui permet de faire la copie des photos chargees par le user
 //dans notre chemin specifie
    function copyPhoto($photo, $chemin) {
        copy($photo, $chemin);
    }
//fonction qui permet d'enregistrer des donnees dans mon fichier json
    function insertDonnees($categorie,$user){
       // mettre le contenu du fichier dans une variable
        $donnee = file_get_contents('asset/JSON/file.json');
        // décoder le flux JSON
        $tableau_pour_json = json_decode($donnee);
        //on parcout le fichier json pour voir si le login n'existe pas deja
        $i=0;
       while($i<count($tableau_pour_json[$categorie]) && $tableau_pour_json[$categorie][$i]->{'login'}!=$user["login"]){
            $i++;
        }
        //si non on enregistre les donnees dans le fichier
        if($i==count($tableau_pour_json[$categorie])){
            //on copie la photo de profil charge par le user dans notre dossier
            copyPhoto($user["ppCharge"], $user["photo"]) ;
            //on insert les infos dans le json
            array_push( $tableau_pour_json[$categorie], array(
                'nom' => $user['nom'],
                'prenom' => $user['prenom'],
                'login' => $user['login'],
                'password' => $user['password'],
                'photo' => $user['photo'],
                "meilleurScore"=>0
            ));
            if($_GET["page"]==0){
                header("Location:index.php");
            }
            echo "<div class='ereur'>Votre compte a été créé avec succes</div>";
            }
        //si oui on dit a l'utilisateur que le login exite deja
        else{
           echo "<div class='ereur'>Login existant</div>";
        }
        // On réencode en JSON
        $contenu_json = json_encode($tableau_pour_json);
        // On stocke tout le JSON
        file_put_contents('asset/JSON/file.json', $contenu_json);
    }
    //fonction permet de faire le trie d'un tableau dans l'ordre decroissant
    function tri($b, $a){
        if ($a->{"meilleurScore"} == $b->{"meilleurScore"}) {
            return 0;
        }
        return ($a->{"meilleurScore"} < $b->{"meilleurScore"}) ? -1 : 1;
    }

      //on renseigne que le joueur a gagne la question dans la partie quizz
    function win($question,$obj){
        foreach($obj as $element){
            if($question->{"question"}==$element->{"question"}){
                $k=0;
                while($k<count($element->{"gagnePar"}) && $_SESSION["loginJoueur"]!=$element->{"gagnePar"}[$k]){
                    $k++;
                }
                if($k==count($element->{"gagnePar"})){
                    $element->{"gagnePar"}[]=$_SESSION["loginJoueur"];
                    $contenu_json=json_encode($obj);
                    file_put_contents('asset/JSON/listeQuestions.json',$contenu_json);
                }
            }
        }
    }
?>