<!DOCTYPE html>
    <head>
        <title>Liste des questions</title>
    </head>
    <body>
    <script type="text/javascript" src="asset/JS/fonctionQcm.js"></script>
        <?php
         // mettre le contenu du fichier dans une variable
         $data = file_get_contents('asset/JSON/listeQuestions.json');
         // décoder le flux JSON
         $obj = json_decode($data);
         //fixe le nbre que questions/jeu
          //pour la validation en php que le nbre de questions/jeu fixe est inferieur ou egal au nbre de questions deans le json
         if(isset($_POST["ok"])){
            if($_POST["nombreQst"]>count($obj)){
               ?>
                <script>affichError(document.getElementById("ereur"),"Ce nombre est superieur au nombre de questions disponibles");</script>
               <?php
            }
            else{
               $donnee = file_get_contents('asset/JSON/nbreQuestions.json');
               $objet = json_decode($donnee);
               //on insere le nbre dans le fichier json
                $objet=$_POST["nombreQst"];
               // On réencode en JSON
                $contenu_json = json_encode($objet);
                // On stocke tout le JSON
                file_put_contents('asset/JSON/nbreQuestions.json', $contenu_json);
            }
         }
          //suppression d'une question
        if(isset($_GET["deleteQst"])){
              //$numQuestion recoit la valeur de $_GET("deleteQst")
              //$_GET["deleteQst"] est le numero de la question a supprimer
                $numQuestion=$_GET["deleteQst"];
                for($i=0;$i<count($obj);$i++){
                    if($i==$numQuestion){
                        unset($obj[$i]);
                    }
                }
                //on le remet le contenu json sous forme de tableau
                $json=array_values($obj);
                //on le reencode
                $json=json_encode($json);
                //on enregistre le tt
                file_put_contents('asset/JSON/listeQuestions.json',$json);
        }
            //affichage des questions
        if(!isset($_GET["editQst"]) || isset($_POST["ok"])){
        ?>
        <div class="nbreQuest">Nbre de questions/Jeu<form method="POST" action=<?php echo 'index.php?page=3&pagiQst='.$_GET["pagiQst"]?> class="formQst" name="formulaire" onsubmit="return nbreQuestion()"><input type="text" class="inputNbre" name="nombreQst"><a href="index.php?page=3"><input type="submit" class="ok" value="Ok" name="ok"></a></form></div>
        <div class="middle">
        <?php
            $verif=[];
            //le nombre total de pages
            $nbrePage = count($obj)/5;
            if($_GET["pagiQst"]>=0){
                //l'indice de la premiere question a afficher pour chaque page
                $debut=5*$_GET["pagiQst"];
                for($i=$debut;$i<$debut+5;$i++){
                    if(isset($obj[$i])){
                        ?>
                        <span><?php echo ($i+1).'. '.$obj[$i]->{"question"}?></span>
                        <!-- l'url pour la suppression de question -->
                        <a href=<?php echo 'index.php?page=3&pagiQst='.$_GET["pagiQst"].'&deleteQst='.$i?> onclick="return confirm('Voulez-vous vous supprimer cette question?')"><span class='style4-qcm' ></span></a>
                        <!-- l'url por l'edition de question -->
                        <a href=<?php echo 'index.php?page=3&editQst='.$i?>><span class="style5-qcm"></span></a>
                        <?php
                        if($obj[$i]->{"type"}=="multiple"){
                            for($j=0;$j<count($obj[$i]->{"reponse"});$j++){
                                ?>
                                    <div class="style2-qcm">
                                        <input class="style3-qcm" type="checkbox" name="<?php echo 'choix'.$i.$j?>" value=<?php echo $obj[$i]->{"reponse"}[$j]?> <?php $verif=$obj[$i]->{"reponse"}[$j]?>  <?php foreach($obj[$i]->{"reponseJuste"} as $element){if($verif==$element){echo "checked";} }?>><?php echo $obj[$i]->{"reponse"}[$j]?>
                                    </div>
                                <?php
                            }
                        }
                        if($obj[$i]->{"type"}=="simple"){
                            for($j=0;$j<count($obj[$i]->{"reponse"}->{"rep"});$j++){
                                ?>
                                <div class="style2-qcm">
                                <input type="radio" name=<?php echo 'choix'.$i?> value=<?php echo 'reponse'.$obj[$i]->{"reponse"}->{"num"}[$j]?> id=<?php echo 'id'.$i.$j?> <?php $verif='reponse'.$obj[$i]->{"reponse"}->{"num"}[$j]; if($verif==$obj[$i]->{"reponseJuste"}[0]){echo "checked";} ?>><?php echo $obj[$i]->{"reponse"}->{"rep"}[$j] ?>
                                </div>
                                <?php
                            }
                                ?>
                            <?php
                        }
                        if($obj[$i]->{"type"}=="texte"){
                            ?>
                                <div class="style2-qcm">
                                    <input type="text" class="style9-qcm" value="<?php echo $obj[$i]->{"reponseJuste"}?>" readonly="readonly">
                                </div>
                            <?php
                        }
                    }
                }
            ?>
                </div>
                <div class="bottom">
                    <?php
                        if($_GET["pagiQst"]>0){
                            $precedent=$_GET["pagiQst"]-1;
                    ?>
                            <a class="btn-precedent deconnect" href="index.php?page=3&pagiQst=<?php echo $precedent?>">Precedent</a>
                            <?php
                        }
                        if($_GET["pagiQst"]<$nbrePage-1){
                            $suivant = $_GET["pagiQst"]+1;
                            ?>
                                <a class="btn-suivant deconnect" href="index.php?page=3&pagiQst=<?php echo $suivant?>">Suivant</a>
                            <?php
                        }
                    }       
                }
            ?>
        </div>
    </body>
</html>