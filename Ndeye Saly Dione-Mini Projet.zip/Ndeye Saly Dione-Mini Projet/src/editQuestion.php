<?php
      
    //le numero de la question qu'on souhaite modifier
    $numQuestion=$_GET["editQst"];
    $choix=[];
    $ereur1 = $ereur2 = $question = "";
    $score = null;
    // mettre le contenu du fichier dans une variable
    $data = file_get_contents('asset/JSON/listeQuestions.json');
    // décoder le flux JSON
    $obj = json_decode($data);
    //on recupere la question correspondant dont l'indice est la valeur de $numQuestion
    $questionnaire=$obj[$numQuestion];
    if(empty($obj[$numQuestion]->{"dejaJoue"})){
        ?>
        <div class="ereur">
        <?php
        echo "La question ne peut etre modifiée car elle n'est pas encore jouée";
        ?>
        </div>
        <?php
      }
      else{
?>
<!DOCTYPE html>
    <head>
        <title>espaceAdmin</title>
        <link rel="stylesheet" href="connexionStyle.css">
    </head>
    <script type="text/javascript" src="asset/JS/fonctionQcm.js"></script>
    <body>
        <h2 class="style6-qcm">Modifier la question</h2>
        <div class="containQst style7-qcm">
            <form method="POST" name="formulaire" id="formulaire" onsubmit="return valid()">
                <div class="style1"><span class="libelle">Questions</span> <textarea class="text-question" name="question" error="error1"><?php echo $obj[$numQuestion]->{"question"} ?></textarea><div id="error1"></div></div>
                <div>Nbre de points <input type="number" class="nbQst" name="nbrePoints" value="<?=$questionnaire->{"points"}?>" error="error2"><span id="error2"></span></div>
                <div>Type de reponse
                    <select class="select" name="type" onchange="generation();" error="error5" id="slct">
                        <option value="0"></option>
                        <option value="multiple">Choix multiple</option>
                        <option value="simple">Choix simple</option>
                        <option value="texte">Choix texte</option>
                    </select><a href="#" onclick="ajout()"><span class="iconSelect"><span></a>
                </div>
                <div id="error5"></div>
                <div class="nbre"></div>
                <!-- ici dans le qcm l'admin ne peut donner au maximum 4 reponses possibles -->
                <?php 
                for($i=0;$i<4;$i++){?>
                <div class="<?php echo 'reponse'.$i?>"></div>
                <?php
                }
                ?>
                <!-- l'input nbreRepMultiple va stocker le nbre de reponses multiples possibles et est de visiblity:hidden -->
                <input type="text" name="nbreRepMultiple" id="nbreRepMultiple">
                <!-- l'input nbreRepSimple va stocker le nbre de reponses simples possibles et est de visiblity:hidden -->
                <input type="text" name="nbreRepSimple" id="nbreRepSimple">
                <div><input type="reset" class="deconnect btn-precedent style8-qcm" name="annuler" value="Annuler"></div>
                <div><input type="submit" class="deconnect btnQst" name="submit" value="Modifier"></div>
            </form>
        </div>
        <?php
            if(isset($_POST["annuler"])){
                header("Location:index.php?page=3&pagiQst=0");
            }
    
            if(isset($_POST["submit"])){
                if(isset($_POST["submit"])){
                    $question = $_POST["question"];
                    $nbrePoints = $_POST["nbrePoints"];
                    $type = $_POST["type"];
                    if($type=="multiple"){
                       for($i=0;$i<4;$i++){
                           if(isset($_POST['rep'.$i])){
                                $reponse[]=$_POST["rep".$i];
                        }
                            if(isset($_POST['choiceMulti'.$i])){
                                $choix[]=$_POST['rep'.$i];     
                            }
                        }
                    }
                    if($type=="simple"){
                        for($i=0;$i<4;$i++){
                            if(isset($_POST['rep'.$i])){
                                $reponse["num"][]=$i+1;
                                $reponse["rep"][]=$_POST['rep'.$i];
                            }
                        }
                        $choix[]=$_POST["choice"];
                    }
                    if($type=="texte"){
                        $reponse[]=$_POST["rep"];
                        $choix=$_POST["rep"];
                    }
                    //on enregistre les modifications dans le fichier json 
                    for($i=0;$i<count($obj);$i++){
                        if($i==$numQuestion){
                        $obj[$i]->{"question"} = $question;
                        $obj[$i]->{"points"} = $nbrePoints;
                        $obj[$i]->{"type"}  = $type;
                        $obj[$i]->{"reponse"} = $reponse;
                        $obj[$i]->{"reponseJuste"} = $choix;
                        // On réencode en JSON
                        $json_contain = json_encode($obj);
                        //on stocke le tout danst le fichier json
                        file_put_contents('asset/JSON/listeQuestions.json',$json_contain);
                        }
                    }
                } 
            }
    
        ?>
    </body>
</html>
<?php
      }
      ?>