<?php
        $_SESSION["classOnglet1"]=$_SESSION["classOnglet2"]="";
        deconnexion($_SESSION["loginJoueur"]);
             // mettre le contenu du fichier dans une variable
             $donnee = file_get_contents('asset/JSON/file.json');
             // décoder le flux JSON
             $obj = json_decode($donnee);
             if(isset($_GET["onglet"])){
                 if($_GET["onglet"]==1){
                    $_SESSION["classOnglet1"] = "ongletActif";
                 }
                 if($_GET["onglet"]==2){
                    $_SESSION["classOnglet2"] = "ongletActif";
                 }
             }
?>
<!DOCTYPE html>
    <head>
        <title>Joueur</title>
    </head>
    <body>
        <script>
            function changeSrc(){
                document.querySelector(".icon2").src = "../asset/IMG/Icones/ic-liste-active.png";
            }
            function changeSrc2(){
                document.querySelector(".icon3").src = "../asset/IMG/Icones/ic-ajout-active.png";
            }
        </script>
        <div class="contain styleAd1">
        <div class="enteteForm style">
            <div class="profilJoueur"><img src="<?php echo $_SESSION["photoJoueur"]?>" class="photoProfil"></div>
            <div class="nomJoueur"><?php echo $_SESSION["prenomJoueur"].' '.$_SESSION["nomJoueur"]?></div>
            <h4 class="bienvenu">BIENVENUE SUR LA PLATEFORME DE JEU DE QUIZZ
                    JOUER ET TESTER VOTRE NIVEAU DE CULTURE GÉNÉRALE</h4>   
            <div class="btnDec"><form method="POST"><input type="submit" name="deconnexion" value="Deconnexion" class="deconnect" onclick="return confirm('Voulez-vous vous deconnecter?')"></form></div>
            </div>
            <div class="espaceJoueur">
                <div class="zoneGauche">
                    <?php
                        require ("src/quizz.php");
                    ?>
                </div>
                <div class="zoneDroite">
                   <div class="onglet">
                            <a class="<?php echo $_SESSION["classOnglet1"].' TpScor'?>" href=<?php echo 'index.php?page=2&onglet=1&pagiQcm='.$_GET["pagiQcm"]?>><span>Top scores</span></a>
                            <a class="<?php echo 'bstScore '.$_SESSION["classOnglet2"] ?>" href=<?php echo 'index.php?page=2&onglet=2&pagiQcm='.$_GET["pagiQcm"]?>><span>Mon meilleur score</span></a>
                   </div>
                   <div class="bottomZone">
                        <?php
                        if(isset($_GET["onglet"])){
                            if($_GET["onglet"]==1){
                                $obj = json_decode($donnee);
                                usort($obj[1], "tri");
                                for($i=0;$i<5;$i++){
                                ?>
                                <table class="tble-top">
                                    <thead>
                                        <th></th>
                                        <th></th>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td><?php echo $obj[1][$i]->{"prenom"}.' '.$obj[1][$i]->{"nom"} ?></td>
                                        <td><?php echo $obj[1][$i]->{"meilleurScore"}?><hr size="5px" class="<?php echo 'score'.$i ?>"></td>
                                    </tr>
                                    <tbody>
                                <?php
                                }
                            }
                            if($_GET["onglet"]==2){
                                ?>
                                <div class="myScore"><?php echo $_SESSION["scoreJoueur"];?></div>
                                <?php
                            }
                        }
                        ?>
                   </div> 
                </div> 
            </div>
        </div>
    </body>
</html>
<?php

