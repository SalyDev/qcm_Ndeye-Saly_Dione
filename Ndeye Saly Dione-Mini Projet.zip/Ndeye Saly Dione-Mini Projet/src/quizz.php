<!DOCTYPE html>
    <head>
        <title>quizz</title>
    </head>
    <body>
        <?php 
         // mettre le contenu du fichier dans une variable
         $donnees = file_get_contents('asset/JSON/reponsesJoueur.json');
        // décoder le flux JSON
        $object = json_decode($donnees);

        //on recupere le nbre de questions par jeu fixe par l'admin
        $nbre = file_get_contents('asset/JSON/nbreQuestions.json');
        $nbre = json_decode($nbre);
            
            // fichier json permettant d'enregistrer les choix du joueur
        $data = file_get_contents('asset/JSON/listeQuestions.json');
        // décoder le flux JSON
        $mesQuestions=[];
        $obj = json_decode($data);
        //$mesQuestions est le tableau qui va contenir l'ensemble des questions qui n'ont pas ete repondus correctement par le joueur
        for($i=0;$i<count($obj);$i++){
            if(!in_array($_SESSION["loginJoueur"],$obj[$i]->{"gagnePar"})){
                    $mesQuestions[]=$obj[$i];
                }
            }
            if($_GET["pagiQcm"]==-1){
                ?>
                <form method="POST">
                    <input type="submit" name="demarrer" value="Demarrer le quizz" class="btn-demarrer">
                </form>
                <?php
                $_SESSION["tab"]=[];
                if(isset($_POST["demarrer"])){
                    // a chaque fois que le quizz demarre on initialise les reponses du joueur a 0 dans le fichier reponsesJoueur.json
                    for($i=0;$i<count($obj);$i++){
                        unset($object[$i]);
                    }
                    $contenu_json=array_values($object);
                    $contenu_json=json_encode($contenu_json);
                    file_put_contents('asset/JSON/reponsesJoueur.json', $contenu_json);
                    //on genere les questions de maniere aleatoire a partir du tableau $mesQuestions
                    $k=0;
                    while($k<count($mesQuestions)){
                            $al=$mesQuestions[mt_rand(0,count($mesQuestions)-1)];
                            if(!in_array($al,$_SESSION["tab"])){
                            $_SESSION["tab"][$k]=$al;
                            $k++;
                        } 
                    }
                    header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm=0');
                }
            }
            else{
                //je met la 2eme condition isset($_SESSION["tab"][$_GET["pagiQCm"]]) pour s'assurer que mm si le nbre de questions de la partie est 5 par exemple s'il ne reste que 3 questions pads gagnees il va joueur que ces 3 questions 
        if($_GET["pagiQcm"]<$nbre && isset($_SESSION["tab"][$_GET["pagiQcm"]])){
                $numQuestion=$_GET["pagiQcm"];
                $question=$_SESSION["tab"][$numQuestion];
                ?>
                    <div class="style10-qcm">
                        <h2><?php echo 'Question '.($numQuestion+1).'/'.$nbre?></h2>
                        <h3 class="style11-qcm">
                            <?php
                            //on affiche la question
                                echo $_SESSION["tab"][$numQuestion]->{"question"};
                            ?>
                        </h3>
                    </div>
                    <div class="style12-qcm">
                        <!-- on affiche le nbre de points -->
                        <?php echo $question->{"points"};?><span class="pts">pts</span>
                    </div>
                <form method="POST">
                <?php
                //si la questio est de type choix simple
                if($question->{"type"}=="simple"){
                    for($i=0;$i<count($question->{"reponse"}->{"rep"});$i++){
                        ?>
                            <div class="style13-qcm"> <input type="radio" name="<?php echo 'choix'.$numQuestion?>" value=<?php echo 'reponse'.$question->{"reponse"}->{"num"}[$i]?> 
                            <?php
                                $checked = 'reponse'.$question->{"reponse"}->{"num"}[$i];   
                                for($j=0;$j<count($object);$j++){
                                    if(isset($object[$j]->{'repGiven'.$numQuestion}) && $checked==$object[$j]->{'repGiven'.$numQuestion}){
                                        echo "checked";
                                    }
                                }
                            ?> 
                            >
                            <?php echo $question->{"reponse"}->{"rep"}[$i]?></div>
                        <?php
                    }
                }
                //si la question est de type choix multiple
                else if($question->{"type"}=="multiple"){
                    for($i=0;$i<count($question->{"reponse"});$i++){
                        ?>
                            <div class="style13-qcm"> <input type="checkbox" name="<?php echo 'choix'.$numQuestion.$i?>" value="<?php echo $question->{"reponse"}[$i]?>" 
                            <?php
                                $check = $question->{"reponse"}[$i];  
                                for($j=0;$j<count($object);$j++){
                                    if(!empty($object[$j]->{'repGiven'.$numQuestion})){
                                        foreach($object[$j]->{'repGiven'.$numQuestion} as $element){
                                            if($check==$element){
                                                echo "checked";
                                            }
                                        }
                                    }
                                }
                            ?>><?php echo $question->{"reponse"}[$i]?></div>
                        <?php
                    }
                }
                //si la question est de type texte
                else{
                    ?>
                        <input  type="text" name=<?php echo 'reponse'.$numQuestion ?> value="<?php foreach($object as $element){if(isset($element->{'repGiven'.$numQuestion})){echo $element->{'repGiven'.$numQuestion};}}?>" class="style14-qcm">
                    <?php
                }
                //on gere la pagination
                if($numQuestion>0){
                    $precedent=$_GET["pagiQcm"]-1;
                    ?>
                    <input type="submit" value="precedent" name="precedent" class="bouton-prec">
                    <?php
                }
                if($numQuestion>=0 && $numQuestion<$nbre-1){
                    $suivant=$_GET["pagiQcm"]+1;
                    ?>
                <input type="submit" value="suivant" name='suivant' class="bouton-suiv">
                    <?php
                }
                ?>
                <!-- bouton pour quitter -->
                <button type="submit" name="quit" class="btn-quit"><img src="asset/IMG/Icones/x-octagon-fill.svg" title="quitter"></button>
                <?php
                if($numQuestion==$nbre-1){
                    $terminer=$_GET["pagiQcm"]+1;
                ?>
                <input type="submit" value="terminer" name='terminer' class="bouton-suiv">
                <?php
                }
                ?>
                </form>
                <?php

                //on gere la pagination
                if(isset($_POST['precedent'])){
                    header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm='.$precedent);
                }
                if(isset($_POST['suivant'])){
                header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm='.$suivant);
                }
                if(isset($_POST["quit"])){
                    header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm='.($nbre+1));
                }
                if(isset($_POST["terminer"])){
                    header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm='.$terminer);
                }
                //enregistrements des reponses du joueur
                if(isset($_POST["suivant"]) || isset($_POST["terminer"]) || isset($_POST["precedent"])){
                    //on rensigne que la question a ete joue par le joueur concerne
                    foreach($obj as $element){
                        if($question->{"question"}==$element->{"question"}){
                            $k=0;
                            while($k<count($element->{"dejaJoue"}) && $_SESSION["loginJoueur"]!=$element->{"dejaJoue"}[$k]){
                                $k++;
                            }
                            if($k==count($element->{"dejaJoue"})){
                            $element->{"dejaJoue"}[]=$_SESSION["loginJoueur"];
                            $contenu_json=json_encode($obj);
                            file_put_contents('asset/JSON/listeQuestions.json',$contenu_json);
                            }
                        }
                    }
                //si la question est de type choix simple
                if($question->{"type"}=="simple"){
                    if(isset($_POST['choix'.$numQuestion])){
                        $reponse = $_POST['choix'.$numQuestion];
                        if($reponse==$question->{"reponseJuste"}[0]){
                            $points=$question->{"points"};
                            //on renseigne que que la reponse a ete trouvee par le joueur
                            win($question,$obj);
                            $src="asset/IMG/Icones/right.png";
                        }
                        else{
                            $src="asset/IMG/Icones/wrong.png";
                        }
                    }
                    else{
                        $reponse = "";
                    }
                }
                //si la question est de choix multiple
                if($question->{"type"}=="multiple"){
                    $reponse=[];
                    $repCorrect=$repIncorrect=[];
                    for($j=0;$j<count($question->{"reponse"});$j++){
                        if(isset($_POST['choix'.$numQuestion.$j])){
                            $reponse[]=$_POST['choix'.$numQuestion.$j];
                            $k=0;
                            while($k<count($question->{"reponseJuste"}) && $_POST['choix'.$numQuestion.$j]!=$question->{"reponseJuste"}[$k]){
                                $k++;
                            }
                            //on recupere les reponses correctes
                            if($k==count($question->{"reponseJuste"})){
                                $src[$j+1]="asset/IMG/Icones/wrong.png";
                                $repIncorrect[]=$_POST['choix'.$numQuestion.$j];
                            }
                            //on recupere les reponses incorrectes
                            else{
                                $src[$j+1]="asset/IMG/Icones/right.png";
                                $repCorrect[]=$_POST['choix'.$numQuestion.$j];
                                win($question,$obj);
                            }
                        }
                    }
                    //on donne le nbre de points si le joueur a gagne
                    if(count($repIncorrect)==0 && count($repCorrect)==count($question->{"reponseJuste"})){
                        $points=$question->{"points"};
                    }
                }
                //si la reponse est de choix texte
                if($question->{"type"}=="texte"){
                    if(!empty($_POST['reponse'.$numQuestion])){
                        $reponse=$_POST['reponse'.$numQuestion];
                        if($reponse==$question->{"reponseJuste"}){
                            $points=$question->{"points"};
                            $src="asset/IMG/Icones/right.png";
                            win($question,$obj);
                        }
                        else{
                            $src="asset/IMG/Icones/wrong.png";
                        }
                    }
                }
                $i=0;
                while($i<count($object) && $question->{"question"}!=$object[$i]->{"question"}){
                    $i++;
                }
                if($i==count($object)){
                    $object[]=array(
                        "question" => $question->{"question"},
                        'repGiven'.$numQuestion => $reponse,
                        "numQst" => $numQuestion,
                        "points" => $points,
                        "src" => $src,
                        "repCorrect" => $repCorrect,
                        "repIncorrect" => $repIncorrect
                    );
                }
                else{
                    $object[$i]=array(
                        "question" => $question->{"question"},
                        'repGiven'.$numQuestion => $reponse,
                        "numQst" => $numQuestion,
                        "type" => $question->{"type"},
                        "points" => $points,
                        "src" => $src,
                        "repCorrect" => $repCorrect,
                        "repIncorrect" => $repIncorrect
                    );
                }
                // On réencode en JSON
                $contenu_json = json_encode($object);
                // On stocke tout le JSON
                file_put_contents('asset/JSON/reponsesJoueur.json', $contenu_json);
            }
        }
        else{
            ?>
                <script>document.querySelector(".zoneGauche").classList.add("style15-qcm");</script>
                <?php
                $scoreFinal=0;
                for($i=0;$i<count($object);$i++){
                    if(isset($object[$i]->{"points"})){
                        $scoreFinal=$scoreFinal+$object[$i]->{"points"};
                    }
                }
                //on update le meilleur score du joueur si le score obtenu a la fin de la partie est superieur a son precedent score
                $file = file_get_contents('asset/JSON/file.json');
                // décoder le flux JSON
                $file_decode = json_decode($file);
                for($i=0;$i<count($file_decode[1]);$i++){
                    if($_SESSION["loginJoueur"]==$file_decode[1][$i]->{"login"} && $scoreFinal>$file_decode[1][$i]->{"meilleurScore"}){
                        $file_decode[1][$i]->{"meilleurScore"}=$scoreFinal;
                        $contenu_json=json_encode($file_decode);
                        file_put_contents('asset/JSON/file.json',$contenu_json);
                    
                    }
                }
                ?>
                    <div class="style-scr">
                    <h3 class="style11-qcm">
                    <?php
                        echo 'Score Total : '.$scoreFinal.'pts';
                    ?>
                    </h3>
                    </div>
                    <?php
                //affichage des resultats du joueur
                for($i=0;$i<count($object);$i++){
                    if(isset($object[$i]->{"points"})){
                        $scoreFinal=$scoreFinal+$object[$i]->{"points"};
                    }
                
                    ?>
                    <!-- on affiche la question -->
                    <div class="style10-qcm">
                    <h3 class="style11-qcm">
                    <?php
                        echo $object[$i]->{"question"};
                    ?>
                    </h3>
                    </div>
                    <?php
                        //on recupere la question dans le fichier listeQuestions.json de base
                    for($j=0;$j<count($obj);$j++){
                        $numQst=$object[$i]->{"numQst"};
                        if($object[$i]->{"question"}==$obj[$j]->{"question"}){
                            $numQuestion=$j;
                        }
                    }
                    //si la question est a choix simple
                    if($obj[$numQuestion]->{"type"}=="simple"){
                        for($k=0;$k<count($obj[$numQuestion]->{"reponse"}->{"num"});$k++){
                            ?>
                            <div class="style13-qcm"> <input type="radio" name=<?php echo 'choix'.$i?> class="<?php echo 'class'.$i.$k ?>"
                            <?php
                                $checked = 'reponse'.$obj[$numQuestion]->{"reponse"}->{"num"}[$k];
                                    if(isset($object[$i]->{'repGiven'.$numQst}) && $checked==$object[$i]->{'repGiven'.$numQst}){
                                        echo "checked";
                                    }
                            ?> 
                            >
                            <?php echo $obj[$numQuestion]->{"reponse"}->{"rep"}[$k]
                            ?>
                            <img src="" class=<?php echo 'img'.$i.$k ?>>
                            </div>
                            <script>
                                if(document.querySelector("<?php echo '.class'.$i.$k ?>").checked){document.querySelector("<?php echo '.img'.$i.$k ?>").src="<?php echo $object[$i]->{"src"}?>"}
                            </script>
                                <?php
                            
                        }
                    }
                    //si la question est de choix multiple
                    else if($obj[$numQuestion]->{"type"}=="multiple"){
                        for($k=0;$k<count($obj[$numQuestion]->{"reponse"});$k++){
                            ?>
                            <div class="style13-qcm"> <input type="checkbox" name="<?php echo 'choix'.$numQuestion.$i?>" class="<?php echo 'classe'.$i.$k ?>"
                            <?php
                                $check = $obj[$numQuestion]->{"reponse"}[$k];  
                                if(isset($object[$i]->{'repGiven'.$numQst})){
                                    foreach($object[$i]->{'repGiven'.$numQst} as $element){
                                        if($check==$element){
                                            echo "checked";
                                        }
                                    }
                                }
                                ?>><?php echo $obj[$numQuestion]->{"reponse"}[$k]?>
                                <img src="" class="<?php echo 'imge'.$i.$k ?>">
                                </div>
                            
                                <script>
                                $n=0;
                                    if(document.querySelector("<?php echo '.classe'.$i.$k ?>").checked){document.querySelector("<?php echo '.imge'.$i.$k ?>").src="<?php echo $object[$i]->{"src"}->{$k+1}?>"}
                                </script>
                                <?php
                                
                            }
                        }
                    //si la question est de type choix texte
                        else{
                            ?>
                            <input class="style14-qcm" type="text" value="<?php echo $object[$i]->{'repGiven'.$numQst}?>"><img src="<?php echo $object[$i]->{"src"} ?>">
                            <?php
                        }
                    }
                ?>
                    <form method="POST">
                        <input type="submit" name="rejouer" value="Commencer une autre partie" class="replay">
                    </form>
                    <?php
                    if(isset($_POST["rejouer"])){
                        header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm=-1');
                    }
                }
            }
    ?>
    <body>
</html>