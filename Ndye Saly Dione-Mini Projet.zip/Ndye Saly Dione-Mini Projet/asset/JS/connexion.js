                                //des qu'on commence a ecrire sur un champs le message d'erreur disparait
                                //on commence par recuperer tous les input et on les
                                //met dans la variable inputs
                                const inputs = document.getElementsByTagName("input");
                                //on parcourt chaque inputs
                                for(input of inputs){
                                    //keyup=>des qu'on leve la main, qu'on commence a ecrire sur le input
                                    //target permet d'inquider le chamsp qui a le focus
                                    //e.target.hasAttribute permet de voir l'affichage d'erreur a ete activie sur
                                    //le input qu'on est entrain d'ecrire
                                    input.addEventListener("keyup",function(e){
                                      if(e.target.hasAttribute("error")){
                                           var idDivError=e.target.getAttribute("error");
                                           document.getElementById(idDivError).innerText="";
                                       } 
                                    })
                                }
                               document.getElementById("connectFormulaire").addEventListener("submit",function(e){
                                   // alert("ok");
                                       //  const inputs = document.getElementsByTagName("input");
                                        // var error=false;
                                        for(input of inputs){
                                           if(input.hasAttribute("error")){
                                                var idDivError=input.getAttribute("error");
                                           if(!input.value){
                                               
                                               document.getElementById(idDivError).innerText="Champs obligatoire";
                                               e.preventDefault(); 
                                               // alert(idDivError);
                                               }
                                               else{
                                                   document.getElementById(idDivError).innerText="";
                                               }
                                               // return false;
                                               
                                               }
                                           }  
                                       });