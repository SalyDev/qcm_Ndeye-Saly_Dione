function testValidation(){
    var nomValid=/^[A-Z][a-zéèê]+(([ ][A-Z][a-zéèê]+)+)?$/;
    var logValid=/[A-Za-z0-9]{2,}/;
    var pwdValid = /.{8,}/;
    var errorPrenom = document.querySelector("#errorPrenom");
    var prenom = document.inscription.prenom.value;
    var nom = document.inscription.nom.value;
    var login = document.inscription.login.value;
    var pwd = document.inscription.pwd.value;
    var confirm = document.inscription.confirm.value;
    var imgElement = document.querySelector('#pp');
    var zoneErreur = document.querySelector('#errorExt');


    //on verifie que le champs prenom n'est pas vide
    if(prenom==""){
        errorPrenom.textContent = "*Obligatoire";
        return false;
    }
     //on verifie si le format du prenom est correcte
     else if(nomValid.test(prenom)==false){
        errorPrenom.textContent = "*Incorrecte";
        return false;
    }
    else{
        errorPrenom.textContent = ""; 
    }
    //on verifie si le champs nom n'est pas vide
    if(nom==""){
        errorNom.textContent = "*Obligatoire";
        return false;
    }
    //on verifie le format du nom
    else if(nomValid.test(nom)==false){
        errorNom.textContent = "*Incorrecte";
        return false;
    }
    else{
        errorNom.textContent = ""; 
    }

    //on verifie que le champs login est rempli
    if(login==""){
        errorLog.textContent = "*Obligatoire";
        return false;
    }
    //on verifie le format du login
    else if(logValid.test(login)==false){
        errorLog.textContent = "*Incorrecte";
        return false;
    }
    else{
        errorLog.textContent = ""; 
    }

    //on verifie que le champs pwd est rempli
    if(pwd==""){
        errorPwd.textContent = "*Obligatoire";
        return false;
    }
    //on verifie le format du password
    else if(pwdValid.test(pwd)==false){
        alert("Le mot de passe contient au moins 8 caracteres");
        errorPwd.textContent = "*Incorrecte";
        return false;
    }
    else{
        errorPwd.textContent = ""; 
    }

    //on verifie que le champs confirm n'est pas vide
    if(confirm==""){
        errorConf.textContent = "*Obligatoire";
        return false;
    }
    //on verifie que les 2 password sont identiques
    if(confirm!=pwd){
        errorConf.textContent = "*Pas identiques";
        return false;
    }
    else{
        errorConf.textContent = ""; 
    }
    //on verifie que l'utilisateur a bien choisi ton photo de profil
    if(imgElement.src==""){
        zoneErreur.textContent = "Veuillez choisir une image";
        zoneErreur.style.color = "red";
        return false;
    }  
}

//fonction permettant d'afficher un message d'erreur sur un emplcement specifique
function affichError(emplacement,msg){
    // emplacement=document.getElementById("ereur");
    emplacement.innerText=msg;
    emplacement.className = "ereur";
}

//cette fonction valid() est utilisee dans la creation de questions par l'admin au niveau de la page creationQuestion.php
const inputs = document.getElementsByTagName("input");
function valid(){
    // var error=false;
    document.addEventListener("keyup",function(e){
        if(e.target.hasAttribute("error")){
            var idDivError=e.target.getAttribute("error");
            document.getElementById(idDivError).innerText="";
        } 
    })
    //on verifie que le champs question n'est pas vide
    if(document.formulaire.question.value==""){
        error1.innerText = "*Obligatoire";
        error1.style.color="red";
        error1.style.fontSize="12px";
        return false;
    }
    //on verifie que les champs input ne sont pas vides
    for(input of inputs){
        if(input.hasAttribute("error")){
            var idDivError=input.getAttribute("error");
            if(!input.value){
                document.getElementById(idDivError).innerText="*Obligatoire";
                document.getElementById(idDivError).style.color="red";
                document.getElementById(idDivError).style.fontSize="12px";
                return false;
            }
            else{
                document.getElementById(idDivError).innerText="";
            }
        }
    }
    //on verifie que le nbre de points par question est superieur a 1
    if(document.formulaire.nbrePoints.value<1){
        document.getElementById("error2").innerText = "*Le nombre de points doit etre superieur ou egale a 1";
        return false;
    }
    //on verifie que l'utilisateur a choisit son type de question
    if(document.formulaire.type.value=="0"){
        error5.innerText = "*Obligatoire";
        error5.style.color="red";
        error5.style.fontSize="12px";
        return false;
    }
    var nbreRepMultiple=document.formulaire.nbreRepMultiple.value;
    var nbreRepSimple=document.formulaire.nbreRepSimple.value;
    //si la question est de type choix multiple
    if(document.formulaire.type.value=="multiple"){
        //si le nbre de reponse possible est inferieur a 2
        if(nbreRepMultiple<2){
            //on affiche le msg d'erreur
            affichError(document.getElementById("ereur"),"Donner au moins deux reponses possibles");
            return false;
        }
        //on verifie que la bonne reponse est indiquee
        //on initialise un compteur a 0
        //si une bonne reponse est indiquee on incremente le compeuteur
        compteur=0;
        for(i=0;i<nbreRepMultiple;i++){
            if(document.getElementById("choice"+i).checked){
            compteur++;
            }
        }
        //si le compteur est egal a 0 ca veut dire qu'aucune bonne reponse n'a ete indique et on affiche le msg d'erreur
        if(compteur==0){
            affichError(document.getElementById("ereur"),"Veuillez indiquer la ou les bonnes reponses");
            return false;
        }
    }
    //on fait la mm chose pour les question a choix simple
    if(document.formulaire.type.value=="simple"){
        if(nbreRepSimple<2){
            affichError(document.getElementById("ereur"),"Donner au moins deux reponses possibles");
            return false;
        }
        count=0;
        for(i=0;i<nbreRepSimple;i++){
            if(document.formulaire.choice[i].checked){
                count++;
            }
        }
        if(count==0){
            affichError(document.getElementById("ereur"),"Veuillez indiquer la ou les bonnes reponses");
            return false;
        }
    }
    if(document.formulaire.type.value=="texte"){
        if(document.querySelector('.nbre').innerHTML==""){
            affichError(document.getElementById("ereur"),"Veuillez indiquer la bonne reponse");
            return false; 
        }
    }
} 
//fin de la fonction valid()

//gestion de la generation des inputs
var nbre;
var i;
var valeur;
var nbreRep;
//la variable nbreRepMultiple represente le nombre de reponses multiples possibles
//la variable nbreRepSimple represente le nombre de reponses simples possibles
var nbreRepMultiple=0;
var nbreRepSimple=0;
document.formulaire.nbreRepMultiple.value=nbreRepMultiple;
document.formulaire.nbreRepSimple.value=nbreRepSimple;

//cette fonction permet de supprimer une reponse possible et prends comme parametre l'id de la reponse
function suppression(monid){
    //on supprime la reponse consernee
    document.querySelector('.reponse'+monid).innerHTML="";
    //decremente le nombre de reponses possibles et on l'affecte de nouveau dans l'input stockant le nbre de reponse possibles
    if(document.formulaire.type.selectedIndex=="1"){
        nbreRepMultiple--;
        document.formulaire.nbreRepMultiple.value=nbreRepMultiple;
    }
    if(document.formulaire.type.selectedIndex=="2"){
        nbreRepSimple--;
        document.formulaire.nbreRepSimple.value=nbreRepSimple;
    }
}
//une fonction permet d'ajouter une reponse possible
function ajout(){
    j=0;
    if(document.formulaire.type.selectedIndex=="1"){
        while(j<4){
            if(document.querySelector('.reponse'+j).innerHTML==""){
                document.querySelector('.reponse'+j).innerHTML = "Reponse "+(j+1)+"<input type=\"text\" class=\"select\" name=\"rep"+j+"\" error=\"erreur"+j+"\"><input type=\"checkbox\" name=\"choiceMulti"+j+"\" id=\"choice"+j+"\" value=\"reponse"+(j+1)+"\"><a href=\"#\" onclick=\"suppression("+j+"\)\"><span class=\"corbeille\"></span></a><span id=\"erreur"+j+"\"></span>";
                nbreRepMultiple++;
                document.formulaire.nbreRepMultiple.value=nbreRepMultiple;
                break;
            }
            j++; 
        }
    }
    if(document.formulaire.type.selectedIndex=="2"){
        k=0;
        while(k<4){
            if(document.querySelector('.reponse'+k).innerHTML==""){
                nbreRepSimple++;
                document.formulaire.nbreRepSimple.value=nbreRepSimple;
                document.querySelector('.reponse'+k).innerHTML = "Reponse "+(k+1)+"<input type=\"text\" class=\"select\" name=\"rep"+k+"\" error=\"erreur"+k+"\"><input type=\"radio\" name=\"choice\" value=\"reponse"+(k+1)+"\"><a href=\"#\" onclick=\"suppression("+k+"\)\"><span class=\"corbeille\"></span></a><span id=\"erreur"+k+"\"></span>";
            break;
            }   
            k++;
        } 
    }  
    if(document.formulaire.type.selectedIndex=="3"){
        document.querySelector('.nbre').innerHTML = " Reponse <input type=\"text\" class=\"select\" name=\"rep\" classe=\"syleRep\" error=\"error6\"><div id=\"error6\"></div>";
    }
}

//fonction permettant de renouveller le choix du type de questions
function generation(){
        if(document.formulaire.type.selectedIndex=="1"){
            document.querySelector('.nbre').innerHTML = "";
            for(i=0;i<4;i++){
                document.querySelector('.reponse'+i).innerHTML = "";  
            }
        }
        if(document.formulaire.type.selectedIndex=="2"){
            document.querySelector('.nbre').innerHTML = "";
            for(i=0;i<4;i++){
                document.querySelector('.reponse'+i).innerHTML = "";  
            }
        }
    if(document.formulaire.type.selectedIndex=="3"){
        for(i=0;i<4;i++){
            document.querySelector('.reponse'+i).innerHTML = "";  
        }
    }
}

//fonction permettant de fixer le nombre de questions par jeu
function nbreQuestion(){
    nombreQst=document.formulaire.nombreQst.value;
    if(nombreQst==""){
           //on affiche le message d'erreur
        affichError(document.getElementById("ereur"),"*Champs vide");
        return false;
    }
    nbreValid = /[0-9]/;
    if(!(nbreValid.test(nombreQst) && nombreQst>=5)){
        //on affiche le message d'erreur
        affichError(document.getElementById("ereur"),"Veuillez donner un entier superieur ou egal à 5");
        return false;
    }
}
