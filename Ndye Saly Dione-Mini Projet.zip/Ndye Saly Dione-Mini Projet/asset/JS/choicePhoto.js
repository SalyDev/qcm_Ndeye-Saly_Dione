(function() {
    function createThumbnail(file) {
    //la lecture du fichier
    var reader = new FileReader();
    //on declenche un evennemnt une fois la lecture achevee
    reader.addEventListener('load', function() {
        //on recupere la section ou on veut afficher notre image
        var imgElement = document.querySelector('#pp');
        //on affecte le resultat(chemin) comme la source de notre image
        imgElement.src = this.result;
    });
    //on recupere le fichier sous forme d'url pour pouvoir ensuite l'utiliser
    //comme source
    reader.readAsDataURL(file);
    }
    //la liste des extensions que l'on permet
    var extensionPermise = ['png', 'jpg', 'jpeg', 'gif'],
    uploadInput = document.querySelector('#file');
    uploadInput.addEventListener('change', function() {
        var files = this.files,
        zoneErreur=document.querySelector('#errorExt'),
        profilUser = document.querySelector('.view-pp');
         // on recupere le nom et l'extension de l'image dans un tableau imgExtension
         imgExtenion = files[0].name.split('.');
        //on recupere l'extension qui occupe la derniere position du tableau
        imgExtenion = imgExtenion[imgExtenion.length - 1].toLowerCase();
        if (extensionPermise.indexOf(imgExtenion) != -1) {
            //si l'extension est autorisee on recupere le fichier
            createThumbnail(files[0]);
            profilUser.className = "profilUser";
            zoneErreur.innerText = "";
            }
        else{
            zoneErreur.innerText = "Mauvaise extension";
            zoneErreur.style.color = "red";
        }
        });
    })();