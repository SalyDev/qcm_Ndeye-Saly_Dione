<!DOCTYPE html>
    <head>
        <title>QCM</title>
        <link rel="stylesheet" href="asset/CSS/designA17.css">
    </head>
    <body>
        <div class="conteneur">
            <div class="main">
                <h1 class="entete"><img class="logo" src="asset/IMG/logo-QuizzSA.png">Le plaisir de jouer</h1>
                <?php
            if(isset($_GET["page"])){
                if($_GET["page"]==2){
                    require "src/interfaceJoueur.php";
                }
                if($_GET["page"]==7){
                    require "src/creationUser.php";
                }
                else{
                    require "src/interfaceAdmin.php";
                }
            }
            else{
                require "src/connexion.php";
            }
                ?>
            </div>
        </div>
    </body>
</html>