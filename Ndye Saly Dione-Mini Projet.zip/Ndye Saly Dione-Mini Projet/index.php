<?php ob_start();?>
<?php session_start();?>
<!DOCTYPE html>
    <head>
        <title>QCM</title>
        <meta charset="utf-8">
        <link rel="stylesheet" href="asset/CSS/designA57.css">
    </head>
    <body>
        <div class="conteneur">
            <div class="main">
                <h1 class="entete"><img class="logo" src="asset/IMG/logo-QuizzSA.png">Le plaisir de jouer</h1>
                <div id="ereur"></div>
<?php
                    require "src/fonction.php";
                    if(isset($_GET["page"])){
                        if($_GET["page"]==2){
                            require "src/interfaceJoueur.php";
                        }
                        else if($_GET["page"]==0){
                            require "src/creationUser.php";
                        }
                        else{
                            require "src/interfaceAdmin.php";
                        }
                    }
                    else{
                        require "src/connexion.php";
                    }
                    $content=ob_get_clean();
                    echo $content;
?>
</div>
</div>
    </body>
</html>
<?php
?>