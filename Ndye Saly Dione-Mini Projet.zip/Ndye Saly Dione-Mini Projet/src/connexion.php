<?php 
    $ereur1=$ereur2=$ereur = null;
    $eror="";
    $login = $password = "";
    // mettre le contenu du fichier dans une variable
    $data = file_get_contents('asset/JSON/file.json');
    // décoder le flux JSON
    $obj = json_decode($data);
    if(isset($_POST["submit"])){
        if(!empty($_POST["login"]) && !empty($_POST["password"])){
            $password = $_POST["password"];
            $login = $_POST["login"];
            foreach($obj[0] as $element){
                if($login==$element->{'login'} && $password==$element->{'password'}){
                    $_SESSION["loginAdmin"]=$login;
                    $_SESSION["prenomAdmin"]=$element->{'prenom'};
                    $_SESSION["nomAdmin"]=$element->{'nom'};
                    $_SESSION["passwordAdmin"]=$password;
                    $_SESSION["photoAdmin"]=$element->{'photo'};
                    header("Location:index.php?page=3&pagiQst=0"); 
                }  
                else{
                    $ereur = "Login ou mot de passe incorrecte";
                    $eror = "ereur";
                }
            }
            foreach($obj[1] as $element){
                if($login==$element->{'login'} && $password==$element->{'password'}){
                    $_SESSION["loginJoueur"]=$login;
                    $_SESSION["passwordJoueur"]=$password;
                    $_SESSION["prenomJoueur"]=$element->{'prenom'};
                    $_SESSION["nomJoueur"]=$element->{'nom'};
                    $_SESSION["photoJoueur"]=$element->{'photo'};
                    $_SESSION["scoreJoueur"]=$element->{'meilleurScore'};
                    header("Location:index.php?page=2&onglet=1&pagiQcm=-1");
                }  
                else{
                    $ereur = "Login ou mot de passe incorrecte";
                    $eror = "ereur";
                }
            }  
        }
    }
?>
<div class="<?php echo $eror?>"><?php echo $ereur; ?></div>
<!DOCTYPE html>
    <head>
        <meta charset="utf-8">
        <title>connexion</title>
    </head>
    <body>
        <div class="contain">
            <section class="enteteForm"><h4>Login Form</h4><img class="icon1" src="asset/IMG/Icones/ic-ajout-réponse.png"></section> 
            <form method="POST" id="connectFormulaire" class="connectFormulaire"  name="formulaire">
                <div class="chps"><input class="input login" type="text" name="login" placeholder="Utilisateur" autofocus error="error-1" value="<?=$login?>"><img class="img" src="asset/IMG/Icones/ic-login.png"><span id="error-1"></span></div>
                <div class="chps"><input class="input password" type="password" name="password" placeholder="Mot de passe"  error="error-2" value="<?=$password?>"><img class="img" src="asset/IMG/Icones/ic-password.png"><span id="error-2"></span></div>
                <div><input class="bouton" type="submit" name="submit" value="Connexion" ><a class="inscription" href="index.php?page=0">S'inscrire pour jouer?</a></div>
            </form>
        </div>
        <script type="text/javascript" src="asset/JS/login.js"></script>
    </body>
</html>
<?php
?>
