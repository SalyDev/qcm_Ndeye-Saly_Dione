<?php
    $choix=[];
    $ereur1 = $ereur2 = $question = "";
    $score = null;
      // mettre le contenu du fichier dans une variable
      $data = file_get_contents('asset/JSON/listeQuestions.json');
      // décoder le flux JSON
      $obj = json_decode($data);
    if(isset($_POST["submit"])){
        $question = $_POST["question"];
        $nbrePoints = $_POST["nbrePoints"];
        $type = $_POST["type"];
        if($type=="multiple"){
           for($i=0;$i<4;$i++){
               if(isset($_POST['rep'.$i])){
                    $reponse[]=$_POST["rep".$i];
            }
                if(isset($_POST['choiceMulti'.$i])){
                    $choix[]=$_POST['rep'.$i];     
                }
            }
        }
        if($type=="simple"){
            for($i=0;$i<4;$i++){
                if(isset($_POST['rep'.$i])){
                    $reponse["num"][]=$i+1;
                    $reponse["rep"][]=$_POST['rep'.$i];
                }
            }
            $choix[]=$_POST["choice"];
        }
        if($type=="texte"){
            $reponse[]=$_POST["rep"];
            $choix=$_POST["rep"];
        }
        //on enregistre la question dans le fichier json
        $i=0;
        while($i<count($obj) && $obj[$i]->{'question'}!=$question){
                $i++;
        }
        if($i==count($obj)){
            array_push($obj,array(
                "question" => $question,
                "points" => $nbrePoints,
                "type"  => $type,
                "reponse" => $reponse,
                "reponseJuste" => $choix,
                "dejaJoue" => ""
                )
            );
        }
        else{
            ?>
            <script>
                document.getElementById("ereur").innerText="Question existante"; 
                document.getElementById("ereur").className="ereur";
            </script>
            <?php
        }
        // On réencode en JSON
        $json_contain = json_encode($obj);
        //on stocke le tout danst le fichier json
        file_put_contents('asset/JSON/listeQuestions.json',$json_contain);
    }
?>
<!DOCTYPE html>
    <head>
        <title>espaceAdmin</title>
        <link rel="stylesheet" href="connexionStyle.css">
    </head>
    <script type="text/javascript" src="asset/JS/fonction20.js"></script>
    <body>
        <h2 class="enteteQst">PARAMETRER VOTRE QUESTION</h2>
        <div class="containQst">
            <form method="POST" name="formulaire" id="formulaire" onsubmit="return valid()">
                <div class="style1"><span class="libelle">Questions</span> <textarea class="text-question" name="question" error="error1"></textarea><div id="error1"></div></div>
                <div>Nbre de points <input type="number" class="nbQst" name="nbrePoints" value="<?=$score?>" error="error2"><span id="error2"></span></div>
                <div>Type de reponse
                <select class="select" name="type" onchange="generation();" error="error5">
                    <option value="0"></option>
                    <option value="multiple">Choix multiple</option>
                    <option value="simple">Choix simple</option>
                    <option value="texte">Choix texte</option>
                    </select><a href="#" onclick="ajout()"><span class="iconSelect"><span></a>
                </div>
                <div id="error5"></div>
                <div class="nbre"></div>
                <!-- ici dans le qcm l'admin ne peut donner au maximum 4 reponses possibles -->
                <?php for($i=0;$i<4;$i++){?>
                <div class="<?php echo 'reponse'.$i?>"></div>
                <?php
                }
                ?>
                <!-- l'input nbreRepMultiple va stocker le nbre de reponses multiples possibles et est de visiblity:hidden -->
                <input type="text" name="nbreRepMultiple" id="nbreRepMultiple">
                <!-- l'input nbreRepSimple va stocker le nbre de reponses simples possibles et est de visiblity:hidden -->
                <input type="text" name="nbreRepSimple" id="nbreRepSimple">
                <div><input type="submit" class="deconnect btnQst" name="submit" value="Enregistrer"></div>
            </form>
        </div>
    </body>
</html>