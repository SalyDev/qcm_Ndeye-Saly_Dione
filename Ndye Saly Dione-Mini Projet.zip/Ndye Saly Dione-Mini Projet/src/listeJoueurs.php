<!DOCTYPE html>
    <head>
        <title>ListeJoueurs</title>
    </head>
    <body>
        <h3 class="enteteList">Liste des joueurs par score</h3>
        <div class="containList">
            <table class="tbl-List">
                <thead>
                    <th>Nom</th>
                    <th>Prenom</th>
                    <th>Score</th>
                </thead>
                <tbody>
                   <?php
                    // mettre le contenu du fichier dans une variable
                    $donnee = file_get_contents('asset/JSON/file.json');
                    // décoder le flux JSON
                    $obj = json_decode($donnee);
                    usort($obj[1], "tri");
                    $nbrePage = count($obj[1])/15;
                        if($_GET["pagiJoueur"]>=0){
                           $debut=15*$_GET["pagiJoueur"];
                           for($i=$debut;$i<$debut+15;$i++){
                               if(isset($obj[1][$i])){
                            ?>
                                <tr>
                                    <td><?php echo $obj[1][$i]->{"nom"} ?></td>
                                    <td><?php echo $obj[1][$i]->{"prenom"} ?></td>
                                    <td><?php echo $obj[1][$i]->{"meilleurScore"}.' '?><span class="pts">pts</span></td>
                                <tr>
                            <?php
                            }
                         }
                        }
                   ?>
                <tbody>
            </table>
        </div>
        <?php
            if($_GET["pagiJoueur"]>0){
                $precedent = $_GET["pagiJoueur"]-1;
                ?>
                    <a class="btn-precedent deconnect" href="index.php?page=6&pagiJoueur=<?php echo $precedent?>">precedent</a>
                <?php
            }
            if($_GET["pagiJoueur"]<($nbrePage-1)){
                $suivant = $_GET["pagiJoueur"]+1;
                ?>
                    <a class="btn-suivant deconnect" href="index.php?page=6&pagiJoueur=<?php echo $suivant?>">suivant</a>
                <?php
            }

                ?>
    </body>
</html>