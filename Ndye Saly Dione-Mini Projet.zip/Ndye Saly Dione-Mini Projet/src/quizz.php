<?php
    

?>
<!DOCTYPE html>
    <head>
        <title>quizz</title>
    </head>
    <body>
    <?php
    // mettre le contenu du fichier dans une variable
       $data = file_get_contents('asset/JSON/listeQuestions.json');
       // décoder le flux JSON
       $obj = json_decode($data);
       if($_GET["pagiQcm"]==-1){
       ?>
       
       
    <form method="POST">
        <input type="submit" name="demarrer" value="Demarrer le quizz" class="btn-demarrer">
    </form>
        <?php
    
         $_SESSION["tab"]=[];
         if(isset($_POST["demarrer"])){
         $k=0;
         while($k<count($obj)){
                  $al=$obj[mt_rand(0,count($obj)-1)];
                  if(!in_array($al,$_SESSION["tab"])){
                  $_SESSION["tab"][$k]=$al;
                  $k++;
              }
              
          }
          header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm=0');
      }
    }
    else{
      $numQuestion=$_GET["pagiQcm"];
      $question=$_SESSION["tab"][$numQuestion];
      ?>
        <div class="style10-qcm">
            <h2><?php echo 'Question '.($numQuestion+1).'/'.count($obj)?></h2>
            <h3 class="style11-qcm">
                <?php
                //on affiche la question
                    echo $_SESSION["tab"][$numQuestion]->{"question"};
                ?>
            </h3>
        </div>
        <div class="style12-qcm">
            <!-- on affiche le nbre de points -->
              <?php echo $question->{"points"};?><span class="pts">pts</span>
        </div>
      <form method="POST">
      <?php
      //si la questio est de type choix simple
      if($question->{"type"}=="simple"){
          for($i=0;$i<count($question->{"reponse"}->{"rep"});$i++){
              ?>
                  <div class="style13-qcm"> <input type="radio" name="<?php echo 'choix'.$numQuestion?>" value=<?php echo 'reponse'.$question->{"reponse"}->{"num"}[$i]?> <?php  ?> ><?php echo $question->{"reponse"}->{"rep"}[$i]?></div>
              <?php
          }
      }
      //si la question est de type choix multiple
      else if($question->{"type"}=="multiple"){
        for($i=0;$i<count($question->{"reponse"});$i++){
            ?>
                <div class="style13-qcm"> <input type="checkbox" name="<?php echo 'choix'.$numQuestion.$i?>" value="<?php echo $question->{"reponse"}[$i]?>" <?php if(!empty($_POST['choix'.$numQuestion.$i]) && (isset($_SESSION['repCorrectM'][$numQuestion][$i]) || isset($_SESSION['repIncorrectM'][$numQuestion][$i]) )){echo "checked";}?>><?php echo $question->{"reponse"}[$i]?></div>
            <?php
        }
    }
    //si la question est de type texte
    else{
        ?>
            <input  type="text" name=<?php echo 'reponse'.$numQuestion ?> value="<?=$_SESSION["reponse"][$numQuestion]?>" class="style14-qcm">
        <?php
    }
      //on gere la pagination
      if($numQuestion>0){
        $precedent=$_GET["pagiQcm"]-1;
        ?>
        <input type="submit" value="precedent" name="precedent" class="bouton-prec">
        <?php
    }
    if($numQuestion>=0 && $numQuestion<count($obj)-2){
        $suivant=$_GET["pagiQcm"]+1;
        ?>
       <input type="submit" value="suivant" name='suivant' class="bouton-suiv">
        <?php
    }
    if($numQuestion==count($obj)-1){
        $terminer=$_GET["pagiQcm"]+1;
        ?>
       <input type="submit" value="terminer" name='terminer' class="bouton-suiv">
        <?php
    }
    ?>
    </form>
    <?php

    if(isset($_POST['precedent'])){
        header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm='.$precedent);
      }
       if(isset($_POST['suivant'])){
        header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm='.$suivant);
        }
    }
?>
    <body>
</html>