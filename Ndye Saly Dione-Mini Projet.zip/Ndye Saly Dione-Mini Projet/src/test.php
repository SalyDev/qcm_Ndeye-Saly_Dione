<?php
    // chemin d'accès à votre fichier JSON
    // $file = '../asset/JSON/file.json';
    // mettre le contenu du fichier dans une variable
//     $donnee = file_get_contents('../asset/JSON/file.json');
//     // décoder le flux JSON
//     $obj = json_decode($donnee);
// //   var_dump($obj);
//   var_dump($obj->{'admin'});
//  echo $obj->{'admin'}[0]->{"nom"};
// for($i=0;$i<count($obj->admin);$i++){
//     // foreach($obj->{'admin'}[$i]->{'login'} as $element){
//     //     echo $element;
//     // }
//     echo $obj->{'admin'}[$i]->{'login'};
// }
// foreach($obj->admin as $element){
//     echo $element->{'login'};
// }
//   $date = $obj->{'response'}->{'features'}->{'date'};
//   $heur1 = $obj->{'cotation_bourse'}[1]->{'bourse'}->{'heure'};
  
//   $tot = $obj->{'cotation_bourse'}[0]->{'total'}->{'cotation'};
//   echo $heur1;
//  $contenu_json = json_encode($tableau_pour_json); //convertir le tableau au format json
 
// mettre le contenu du fichier dans une variable
 $donnee = file_get_contents('../asset/JSON/file.json');
// décoder le flux JSON
$obj = json_decode($donnee);
$nom = "Fall";
$prenom = "Bintou";
$login = "Fatou";
$pass = "binta20202";
$photo = "mytof";
 // On récupère le JSON dans un tableau PHP
 $tableau_pour_json = json_decode($donnee);
    $i=0;
while($i<count($tableau_pour_json->{'admin'}) && $tableau_pour_json->{'admin'}[$i]->{'login'}!=$login){
    $i++;
}
if($i==count($tableau_pour_json->{'admin'})){
array_push( $tableau_pour_json->{'admin'}, array(
    'nom' => $nom,
    'prenom' => $prenom,
    'login' => $login,
    'password' => $pass,
    'photo' => $photo
));
}
// On réencode en JSON
$contenu_json = json_encode($tableau_pour_json);
// On stocke tout le JSON
file_put_contents('../asset/JSON/file.json', $contenu_json);
 

echo "Vos informations ont été enregistrées";
// $fichierStockage = '../asset/JSON/file.json';
// $fichierStockage = fopen($fichierStockage, 'a+'); //ouvre le fichier
// fclose($fichierStockage);  //ferme le fichier

var_dump($obj);
// foreach($tableau_pour_json->{'admin'} as $element){
//     echo $element->{'login'};
// }

//  var_dump($tableau_pour_json->{'admin'});
//  $bla="hgdf";
//  foreach($tableau_pour_json->{'admin'} as $element){
//      if($element->{'login'}!=$login){
//     echo $element->{'login'};
//      }
// }
//  var_dump($tableau_pour_json->{'admin'});
//  $bla="hgdf";
//  foreach($tableau_pour_json->{'admin'} as $element){
//      if($element->{'login'}!=$login){
//     echo $element->{'login'};
//      }
// }

?>
<input type="file">
