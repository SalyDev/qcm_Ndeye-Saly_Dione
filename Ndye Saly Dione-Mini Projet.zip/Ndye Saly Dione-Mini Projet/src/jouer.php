<?php

           
            //    $tab=[];
            //    $k=0;
              
        //     //    while($k<4){
        //         // if($_GET["pagiQcm"]==0){
        //             $_SESSION["t"]=[];
        //        while($k<count($obj)){
        //            $valGenere=$obj[mt_rand(0,count($obj)-1)];
        //            if(!in_array($valGenere,$_SESSION["t"])){
        //            $_SESSION["t"][]=$valGenere;
                  
        //        }
        //        $k++;
        //    }
        // // }
        // var_dump($_SESSION["tab"]);
        // echo $_SESSION["tab"][1]->{"question"};
         //   for($i=0;$i<count($obj);$i++){
          
            //    $question=$obj[$numQuestion];
              

?>
<!DOCTYPE html>
    <head>
        <title>Liste des questions</title>
    </head>
    <body>
        <?php
            // mettre le contenu du fichier dans une variable
            $data = file_get_contents('asset/JSON/listeQuestions.json');
            // décoder le flux JSON
            $obj = json_decode($data);
            // if($_GET["pagiQcm"]<count($obj)){
                //   $tab=[];
                // $numQuestion=$_GET["pagiQcm"];
                // $question=$_SESSION["t"][$numQuestion];

                $btn_demarrer="";
                $methode="POST";
                if($_GET["pagiQcm"]==0){
                ?>
                
                
             <form method="<?php  echo $methode?>">
                 <input type="submit" name="demarrer" value="Demarrer" class=<?php echo $btn_demarrer?>>
             </form>
                 <?php
                }
                  $_SESSION["tab"]=[];
                  if(isset($_POST["demarrer"])){
                  $k=0;
                  while($k<count($obj)){
                           $al=$obj[mt_rand(0,count($obj)-1)];
                           if(!in_array($al,$_SESSION["tab"])){
                           $_SESSION["tab"][$k]=$al;
                           $k++;
                       }
                       
                   }
                   require "src/jouer.php";
                   $methode="GET";
                   // var_dump($_SESSION["tab"]);
               }

                $numQuestion=$_GET["pagiQcm"];
                // // $question=$obj[$numQuestion];
          
            ?>

            <div class="style10-qcm">
                <h2><?php echo 'Question '.($numQuestion+1).'/'.count($obj)?></h2>
                <h3 class="style11-qcm">
                <?php
                    $question=$_SESSION["tab"][$numQuestion];
                    echo $_SESSION["tab"][$numQuestion]->{"question"};
                ?>
                </h3>
            </div>
            <div class="style12-qcm">
              <?php echo $question->{"points"};?><span class="pts">pts</span>
            </div>
            <form method="POST">
            <?php
                if($question->{"type"}=="simple"){
                    for($i=0;$i<count($question->{"reponse"}->{"rep"});$i++){
                        ?>
                            <div class="style13-qcm"> <input type="radio" name="<?php echo 'choix'.$numQuestion?>" value=<?php echo 'reponse'.$question->{"reponse"}->{"num"}[$i]?> <?php  ?> ><?php echo $question->{"reponse"}->{"rep"}[$i]?></div>
                        <?php
                    }
                }
                else if($question->{"type"}=="multiple"){
                    for($i=0;$i<count($question->{"reponse"});$i++){
                        ?>
                            <div class="style13-qcm"> <input type="checkbox" name="<?php echo 'choix'.$numQuestion.$i?>" value="<?php echo $question->{"reponse"}[$i]?>" <?php if(!empty($_POST['choix'.$numQuestion.$i]) && (isset($_SESSION['repCorrectM'][$numQuestion][$i]) || isset($_SESSION['repIncorrectM'][$numQuestion][$i]) )){echo "checked";}?>><?php echo $question->{"reponse"}[$i]?></div>
                        <?php
                    }
                }
                else{
                    ?>
                        <input  type="text" name=<?php echo 'reponse'.$numQuestion ?> value="<?=$_SESSION["reponse"][$numQuestion]?>" class="style14-qcm">
                    <?php
                }
           
            ?>
            <?php
             
                //on gere la pagination
                if($numQuestion>0){
                    $precedent=$_GET["pagiQcm"]-1;
                    ?>
                    <input type="submit" value="precedent" name="precedent" class="bouton-prec">
                    <?php
                }
                if($numQuestion>=0 && $numQuestion<count($obj)){
                    $suivant=$_GET["pagiQcm"]+1;
                    ?>
                   <input type="submit" value="suivant" name='suivant' class="bouton-suiv">
                    <?php
                }
           
          
            ?>
              </form>
          
          <?php
         
          if(isset($_POST['precedent'])){
            header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm='.$precedent);
          }
           if(isset($_POST['suivant'])){
            header('Location:index.php?page=2&onglet='.$_GET["onglet"].'&pagiQcm='.$suivant);
            }

            //on met le contenu des input text
            $_SESSION["reponse"][]="";
           
            if(isset($_POST['suivant']) || isset($_POST['precedent'])){
             if(!empty($_POST['reponse'.$numQuestion])){
                  if($question->{"type"}=="texte"){
                 $_SESSION["reponse"][$numQuestion]=$_POST['reponse'.$numQuestion];
                }
             }
    }



        if(isset($_POST["suivant"])){
               
                for($i=0;$i<count($obj);$i++){
                       //on recupere les reponses simple du user
                    if(isset($_POST['choix'.$i])){
                        $_SESSION['radio'.$i]=$_POST['choix'.$i];


                }
              
                

                    // if()

                    //on recupere les reponses multiples du user
                    if($obj[$i]->{"type"}=="multiple"){
                    for($j=0;$j<count($obj[$i]->{"reponse"});$j++){
                        if(isset($_POST['choix'.$i.$j])){
                            // $check="checked";
                            $k=0;
                            while($k<count($obj[$i]->{"reponseJuste"}) && $_POST['choix'.$i.$j]!=$obj[$i]->{"reponseJuste"}[$k]){
                                $k++;
                            }
                            if($k==count($obj[$i]->{"reponseJuste"})){
                                // if(array_search($_POST['choix'.$i.$j],$_SESSION["repIncorrectM"][$i])==-1){
                              $_SESSION["repIncorrectM"][$i][$j]=$_POST['choix'.$i.$j];  
                            // }
                        }
                            else{
                                $_SESSION["repCorrectM"][$i][$j]=$_POST['choix'.$i.$j];
                            }
                            // $_SESSION['repMultiple'][$i][]=$_POST['choix'.$i.$j];
                            // $check="checked";
                        }
                    }
                }

                }
            }
    // }
// }

    
    
       


    //a la fin de l'affichage des questions dispo
        else{
            $score=0;
            //reponse texte
       for($i=0;$i<count($obj);$i++){
           if(!empty($_SESSION["reponse"][$i])){
        //    echo $_SESSION["reponse"][$i];
           if($obj[$i]->{"type"}=="texte"){
            //    echo $obj[$i]->{"reponseJuste"};
               if($_SESSION["reponse"][$i]==$obj[$i]->{"reponseJuste"}){
                   $score=$score+$obj[$i]->{"points"};
               }
           }
        //    if($obj)
       }

     //reponse simple
     if(isset($_SESSION['radio'.$i])){
         if($_SESSION['radio'.$i]==$obj[$i]->{"reponseJuste"}[0]){
             $score=$score+$obj[$i]->{"points"};
             //je recupere les reponses simples coorectes dans un tableau
             $_SESSION["reponseCorrectS"][$i]=$_SESSION['radio'.$i];
         }
         else{
             //je recupere les reponses simples incorrectes dans un tableau
            $_SESSION["reponseIncorrectS"][$i]=$_SESSION['radio'.$i];
         }
     }

     //reponse multiple
     //pour chaque page a une question je cree un tableau session qui va contenir les selections du joueur
     //#neverGiveUp

 if(isset($_SESSION["repCorrectM"][$i])){ 
var_dump($_SESSION["repCorrectM"][$i]);
 }

 if(isset($_SESSION["repIncorrectM"][$i])){ 
    var_dump($_SESSION["repIncorrectM"][$i]);
     }
}
    

echo $score.'<br/>';
for($i=0;$i<count($obj);$i++){
    if(isset($_SESSION['radio'.$i])){
    echo 'reponse'.$i.'='.$_SESSION['radio'.$i].'</br>';
}
}
// var_dump( $_SESSION["reponseCorrectS"]);
// var_dump( $_SESSION["reponseIncorrectS"]);
for($i=0;$i<count($obj);$i++){
    // unset($_SESSION['radio'.$i]);
// unset($_SESSION["repIncorrectM"][$i]);
// unset($_SESSION["repCorrectM"][$i]);

}
     //fin du else
        }
  
           
    
      
        
         
          ?>
    
            
    </body>
</html>