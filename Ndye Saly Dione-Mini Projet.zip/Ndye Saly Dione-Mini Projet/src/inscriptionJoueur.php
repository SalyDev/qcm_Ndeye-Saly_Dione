<?php
             session_start();
             $_SESSION["nom"][]=$_SESSION["prenom"][]=$_SESSION["adresse"][]=$_SESSION["genre"][]=$_SESSION["satisfy"][]=$_SESSION["langue"][]=$_SESSION["numero"][]="";
             $nom=$prenom=$adresse=$genre=$numero=$confirm=$comment=$satisfy=$ereur1=
             $ereur2=$ereur3=$ereur4=$ereur5=$ereur6=$ereur7=$ereur8=
             $ereur="";
            require "fonction.php";
            $comment=$langues=[];
            if(isset($_POST["submit"])){
                //verification du nom
                if(empty($_POST["nom"])){
                    $ereur1 = "Donnez donner votre nom.";
                }
                else{
                    if(!validNom($_POST["nom"])){
                        $ereur1 = "Nom invalide !";
                    }
                    else{
                        $nom=$_POST["nom"];
                      
                    }
                }
                //verification de prenom
                if(empty($_POST["prenom"])){
                        $ereur2 = "Donnez votre prenom.";
                    }
                else{
                        if(!validNom($_POST["prenom"])){
                            $ereur2 = "Prenom invalide !";
                        }
                        else{
                            $prenom=$_POST["prenom"];
                        }
                }
                //verification du login
                if(empty($_POST["login"])){
                        $ereur1 = "Donnez donner votre nom.";
                }
                 else{
                    if(!validLogin($_POST["login"])){
                        $ereur1 = "Login invalide !";
                    }
                    else{
                        $nom=$_POST["login"]; 
                        }
                    }
                //verification du mot de passe
                if(empty($_POST["password"])){
                    $ereur4 = "Donnez votre mot de passe.";
                }
                else{
                    if(!validPass($_POST["password"])){
                        $ereur4 = "Mot de passe invalide !";
                    }
                    else{
                        $password=$_POST["password"];
                    }
                }
                //verification que le password initial et le password confirme
                //sont identiques
                if(empty($_POST["confirm"])){
                    $ereur5 = "Confirmez votre mot de passe.";
                }
                else{
                    if($_POST["confirm"]!=$_POST["password"]){
                        $ereur5 = "Mot de passe non identiques !";
                    }
                    else{
                        $confirm = $_POST["confirm"];
                    }
                }
            }
         if(!empty($nom) && !empty($prenom) && !empty($password) && ($password==$confirm)){
            array_push($_SESSION["nom"],$nom);
            array_push($_SESSION["prenom"],$prenom);
            array_push($_SESSION["login"],$login);
            array_push($_SESSION["password"],$adresse);
         }
        ?>
    <div class="<?php echo $eror?>"><?php echo $ereur; ?></div>
<?php
    
?>
<!DOCTYPE html>
    <head>
        <title>Inscription</title>
        <link rel="stylesheet" href="../asset/CSS/designA13.css">
    </head>
    <body>
    <div class="conteneur">
        <div class="main">
            <h1 class="entete"><img class="logo" src="../asset/IMG/logo-QuizzSA.png">Le plaisir de jouer</h1>
            <div class="contain espaceInscript">
            <section class="enteteForm"><h4>Inscription</h4><img class="icon1" src="../asset/IMG/Icones/ic-ajout-réponse.png"></section> 
                <form method="POST" class="formul">
                    <div class="chps"><input class="input" type="text" name="prenom" placeholder="Prenom" autofocus value="<?=$login?>" ><img class="img" src="../asset/IMG/Icones/ic-login.png"><span class="ereur"><?php echo $ereur1?></span></div>
                    <div class="chps"><input class="input" type="text" name="nom" placeholder="Nom" autofocus value="<?=$login?>" ><img class="img" src="../asset/IMG/Icones/ic-login.png"><span class="ereur"><?php echo $ereur1?></span></div>
                    <div class="chps"><input class="input" type="text" name="login" placeholder="Login" autofocus value="<?=$login?>" ><img class="img" src="../asset/IMG/Icones/ic-login.png"><span class="ereur"><?php echo $ereur1?></span></div>
                    <div class="chps"><input class="input" type="password" name="password" placeholder="Mot de passe" value="<?=$password?>"><img class="img" src="../asset/IMG/Icones/ic-password.png"><span class="ereur"><?php echo $ereur2?></span></div>
                    <div class="chps"><input class="input" type="password" name="confirm" placeholder="Confirmer votre mot de passe" value="<?=$password?>"><img class="img" src="../asset/IMG/Icones/ic-password.png"><span class="ereur"><?php echo $ereur2?></span></div>
                    Photo de profil : <input type="file">
                    <div><input class="bouton" type="submit" name="submit" value="S'inscrire">
                </form>
            </div>
        </div>
    </div>
    </body>
</html>
