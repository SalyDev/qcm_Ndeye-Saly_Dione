<?php session_start();
        require "fonction.php";
        deconnexion($_SESSION["loginAdmin"]);
        $_SESSION["lienFocus1"]=$_SESSION["lienFocus2"]=$_SESSION["lienFocus3"]
        =$_SESSION["lienFocus4"]="";
        $_SESSION["iconList1"]=$_SESSION["iconList2"]="icon2";
        $_SESSION["iconAjout1"]=$_SESSION["iconAjout2"]="icon3";
        if(isset($_GET["page"])){
            $page = $_GET["page"];
            if($page==1){
                $_SESSION["iconList1"] = "icon2_active";
                $_SESSION["lienFocus1"] = "lienFocus";
            }
            if($page==2){
                $_SESSION["iconAjout1"] = "icon3_active";
                $_SESSION["lienFocus2"] = "lienFocus";
        }   
        if($page==3){
            $_SESSION["iconList2"] = "icon2_active";
            $_SESSION["lienFocus3"] = "lienFocus";
        }
        if($page==4){
            $_SESSION["iconAjout2"] = "icon3_active";
            $_SESSION["lienFocus4"] = "lienFocus";
    }  


    }  
    ?>
<!DOCTYPE html>
    <head>
        <title>Admin</title>
        <link rel="stylesheet" href="../asset/CSS/designA13.css">
    </head>
    <body>
    <script>
        function changeSrc(){
            document.querySelector(".icon2").src = "../asset/IMG/Icones/ic-liste-active.png";
        }
        function changeSrc2(){
            document.querySelector(".icon3").src = "../asset/IMG/Icones/ic-ajout-active.png";
        }
    </script>
    <div class="conteneur">
    <div class="main">
    <h1 class="entete"><img class="logo" src="../asset/IMG/logo-QuizzSA.png">Le plaisir de jouer</h1>
       <div class="contain styeAd1">
       <div class="enteteForm style"><h2 class="styleAd2">CREER ET PARAMETREZ VOS QUIZZ</h2><form class="monForm" method="POST"><input class="deconnect" type="submit" name="deconnexion" value="deconnexion"></form></div> 
            <div class="section1">
                <div class="section1_1">
                    <div class="profil"><img src="<?php echo $_SESSION['photoAdmin'] ?>" class="photoProfil" ></div>
                    <div class="prenomAdmin"><?php echo $_SESSION["prenomAdmin"]?></div>
                    <div class="nomAdmin"><?php echo $_SESSION["nomAdmin"]?></div>
                </div>
                <div class="section1_2">
                    <ul>
                        <a href="interfaceAdmin.php?page=1"><li class="lien <?php echo $_SESSION["lienFocus1"]?>">Liste des questions <span class="<?php echo $_SESSION["iconList1"]?>"></li></span></a>
                        <a href="interfaceAdmin.php?page=2"><li class="lien <?php echo $_SESSION["lienFocus2"]?>">Creer Admin <span class="<?php echo $_SESSION["iconAjout1"]?>"></li></span></a>
                        <a href="interfaceAdmin.php?page=3"><li class="lien <?php echo $_SESSION["lienFocus3"]?>">Liste joueurs <span class="<?php echo $_SESSION["iconList2"]?>"></li></span></a>
                        <a href="interfaceAdmin.php?page=4"><li class="lien <?php echo $_SESSION["lienFocus4"]?>">Creer questions <span class="<?php echo $_SESSION["iconAjout2"]?>"></li></span></a>
                    </ul> 
                </div>
            </div>
            <div class="section2">
                <form method="POST" class="nbreQuest">
                     Nbre de questions/Jeu <input type="text" name="nbreQuest" class="inputNbre"><input type="submit" value="OK" class="ok">
                </form>
                <div class="section2_1"></div>
                <div class="section2_2"><input class="sivant" type="button" value="suivant"></div>
            </div>
        </div>
        </div>
        </div>
    </body>
</html>