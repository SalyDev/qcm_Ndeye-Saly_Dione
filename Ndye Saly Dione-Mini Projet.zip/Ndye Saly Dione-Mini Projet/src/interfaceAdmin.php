<?php   
        deconnexion($_SESSION["loginAdmin"]);
        $_SESSION["lienFocus1"]=$_SESSION["lienFocus2"]=$_SESSION["lienFocus3"]
        =$_SESSION["lienFocus4"]="";
        $section="";
        $_SESSION["style-droite"]="";
        $_SESSION["iconList1"]=$_SESSION["iconList2"]="icon2";
        $_SESSION["iconAjout1"]=$_SESSION["iconAjout2"]="icon3";
        if(isset($_GET["page"])){
            $page = $_GET["page"];
            if($page==3){
                $_SESSION["iconList1"] = "icon2_active";
                $_SESSION["lienFocus1"] = "lienFocus";
                $_SESSION["style-droite"]="section_listQst";
            }
            if($page==4){
                $_SESSION["iconAjout1"] = "icon3_active";
                $_SESSION["lienFocus2"] = "lienFocus";
                $_SESSION["style-droite"]="section2_1";
            }   
            if($page==5){
                $_SESSION["iconAjout2"] = "icon3_active";
                $_SESSION["lienFocus4"] = "lienFocus";
                $_SESSION["style-droite"]="section_made";
            }
            if($page==6){
                $_SESSION["iconList2"] = "icon2_active";
                $_SESSION["lienFocus3"] = "lienFocus";
                $_SESSION["style-droite"]="section_list";
            }
        }
    ?>
<!DOCTYPE html>
    <head>
        <title>Admin</title>
    </head>
    <body>
    <script>
        function changeSrc(){
            document.querySelector(".icon2").src = "asset/IMG/Icones/ic-liste-active.png";
        }
        function changeSrc2(){
            document.querySelector(".icon3").src = "asset/IMG/Icones/ic-ajout-active.png";
        }
    </script>
       <div class="contain styleAd1">
       <div class="enteteForm style"><h2 class="styleAd2">CREER ET PARAMETREZ VOS QUIZZ</h2><form class="monForm" method="POST"><input class="deconnect" type="submit" name="deconnexion" value="deconnexion" onclick="return confirm('Voulez-vous vous deconnecter?')"></form></div> 
            <div class="section1">
                <div class="section1_1">
                    <div class="profil"><img src="<?php echo $_SESSION['photoAdmin'] ?>" class="photoProfil" ></div>
                    <div class="prenomAdmin"><?php echo $_SESSION["prenomAdmin"]?></div>
                    <div class="nomAdmin"><?php echo $_SESSION["nomAdmin"]?></div>
                </div>
                <div class="section1_2">
                    <ul>
                        <a href="index.php?page=3&pagiQst=0"><li class="lien <?php echo $_SESSION["lienFocus1"]?>">Liste des questions <span class="<?php echo $_SESSION["iconList1"]?>"></li></span></a>
                        <a href="index.php?page=4"><li class="lien <?php echo $_SESSION["lienFocus2"]?>">Creer Admin <span class="<?php echo $_SESSION["iconAjout1"]?>"></li></span></a>
                        <a href="index.php?page=6&pagiJoueur=0"><li class="lien <?php echo $_SESSION["lienFocus3"]?>">Liste joueurs <span class="<?php echo $_SESSION["iconList2"]?>"></li></span></a>
                        <a href="index.php?page=5"><li class="lien <?php echo $_SESSION["lienFocus4"]?>">Creer questions <span class="<?php echo $_SESSION["iconAjout2"]?>"></li></span></a>
                    </ul> 
                </div>
            </div>
            <div class="section2">
                <div class="<?php echo $_SESSION["style-droite"]?>">
                    <?php
                        if(isset($_GET["editQst"])){
                            require "src/editQuestion.php";
                        }
                        if($page==4){
                            require "src/creationUser.php";
                        }
                        if($page==5){
                            require "src/creationQuestion.php";
                        }
                        if($page==3){
                            require "src/listeQuestions.php";
                        }
                        if($page==6){
                            require "src/listeJoueurs.php";
                        }
?>
                </div>
            </div>
        </div>
    </body>
</html>