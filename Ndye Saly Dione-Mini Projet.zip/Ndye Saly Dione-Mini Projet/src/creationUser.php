<?php
    $nom=$prenom=$login=$pwd=$confirm="";
    $section = "section2_1";
    if($_GET["page"]==0){
    $but = "Pour tester votre niveau de culture generale";
    $categorie = 1;
    }
    else{
        $but="Pour proposer des quizz";
        $categorie = 0;
    }
    if(isset($_POST["submit"])){
        if(!empty($_POST["nom"])){
            $nom=$_POST["nom"];
            $prenom=$_POST["prenom"];
            $login=$_POST["login"];
            $pwd=$_POST["pwd"];
            $confirm=$_POST["confirm"];
            //on recupere dans notre serveur la photo chargee par le user
            if (isset($_FILES['photoUser']['tmp_name'])) {
                $photoCharge = $_FILES['photoUser']['tmp_name'];
            //les infos de l'utilisateur inscrit
            $user = [   'nom'=> $nom,
                        'prenom' => $prenom,
                        'login' => $login,
                        'password' => $pwd,
                        'ppCharge' => $photoCharge,
                        'photo' => 'asset/IMG/'.$_FILES['photoUser']['name']
                    ];
            //insertion des infos dans le fichier json
            insertDonnees($categorie,$user);
            }
        }
    }
?>
<!DOCTYPE html>
    <head>
        <title>fichier</title>
    </head>
    <body>
    <div class="insrpt_container">
            <div class="inscrp_entete">S'INSCRIRE</div>
            <?php echo $but ?>
            <hr>
            <form method="POST" enctype="multipart/form-data" name="inscription" class="inscrpt_form" onsubmit="return testValidation();">
                <div>Prenom</div>
                <input type="text" name="prenom" class="inscrpt_input" value="<?=$prenom?>"><span id="errorPrenom"></span>
                <div>Nom</div>
                <input class="inscrpt_input" type="text" name="nom" value="<?=$nom?>"><span id="errorNom"></span>
                <div>Login</div>
                <input class="inscrpt_input" type="text" name="login" value="<?=$login?>"><span id="errorLog"></span>
                <div>Password</div>
                <input class="inscrpt_input" type="password" name="pwd" value="<?=$pwd?>"><span id="errorPwd"></span>
                <div>Confimer password</div>
                <input class="inscrpt_input" type="password" name="confirm" value="<?=$confirm?>"><span id="errorConf"></span><br/>
                <div class="parent-div">Avatar
                    <button class="btn-upload">Choisir le fichier</button> <span id="errorExt"></span>
                    <input type="file" id="file" name="photoUser">
                </div>
                <div><a href="#"><input type="submit" value="Creer compte" class="inscrpt_submit" name="submit"></a></div>
                <div class="view-pp"><img id="pp"></div>
            </form>
        </div>
        <script type="text/javascript" src="asset/JS/choicePhoto.js"></script>
        <script type="text/javascript" src="asset/JS/fonction20.js"></script>
    </body>
</html>