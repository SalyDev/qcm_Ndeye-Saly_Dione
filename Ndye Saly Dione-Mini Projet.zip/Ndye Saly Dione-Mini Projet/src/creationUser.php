<?php
    if($_GET["page"]==7){
    $but = "Pour tester votre niveau de culture generale";
    }
    else{
        $but="Pour proposer des quizz";
    }
?>
<!DOCTYPE html>
    <head>
        <title>Creer Admin</title>
    </head>
    <body>
        <div class="insrpt_container">
            <div class="inscrp_entete">S'INSCRIRE</div>
            <?php echo $but ?>
            <hr>
            <form class="inscrpt_form">
                <div>Prenom</div>
                <input type="text" class="inscrpt_input">
                <div>Nom</div>
                <input class="inscrpt_input" type="text" name="nom">
                <div>Login</div>
                <input class="inscrpt_input" type="text" name="login">
                <div>Password</div>
                <input class="inscrpt_input" type="password" name="pwd">
                <div>Confimer password</div>
                <input class="inscrpt_input" type="password" name="confirm"><br>
                <div class="parent-div">Avatar
                    <button class="btn-upload">Choisir le fichier</button>
                    <input type="file" name="upfile">
                </div>
                <div><input type="submit" value="Creer compte" class="inscrpt_submit"></div>
            </form>
            <div class="profilUser"></div>
        </div>
    </body>
</html>